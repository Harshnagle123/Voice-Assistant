import speech_recognition as sr
import os
import webbrowser
import openai
from config import apikey
import datetime
import pyttsx3
import time

chatStr = ""
user_name = "Harsh Nagle"
user_date = "25 November 2023"

def chat(query):
    global chatStr
    global user_name

    print(f"Current chatStr: {chatStr}")
    openai.api_key = apikey
    chatStr += f"Harsh: {query}\njarvis: "

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": chatStr}
            ],
            temperature=0.7,
            max_tokens=256,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0
        )
        response_text = response["choices"][0]["message"]["content"]
        print(response_text)

        if any(keyword in query.lower() for keyword in ["who create you", "who is your developer name", "what is your developer name"]):
            response_text = f"I was created by {user_name}."
        say(response_text, rate=150)
        chatStr += f"{response_text}\n"
        return response_text
    except openai.error.RateLimitError as e:
        print("Rate limit reached. Waiting for 20 seconds...")
        time.sleep(20)
        return chat(query)
    except openai.error.OpenAIError as e:
        print(f"An error occurred: {e}")
        return "I'm having trouble processing your request right now."

def say(text, rate=180):
    try:
        engine = pyttsx3.init()
        engine.setProperty('rate', rate)
        engine.say(text)
        engine.runAndWait()
        print(f"jarvis: {text}")
    except Exception as e:
        print(f"Error in text-to-speech: {e}")

def ai(prompt):
    global chatStr
    openai.api_key = apikey
    text = f"OpenAI response for Prompt: {prompt} \n *************************\n\n"

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=256,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0
        )
        text += response["choices"][0]["message"]["content"]
        if not os.path.exists("Openai"):
            os.mkdir("Openai")

        with open(f"Openai/{''.join(prompt.split('intelligence')[1:]).strip()}.txt", "w") as f:
            f.write(text)
        response_text = "done sir"
    except openai.error.RateLimitError as e:
        print("Rate limit reached. Waiting for 20 seconds...")
        time.sleep(20)
        response_text = ai(prompt)
    except openai.error.OpenAIError as e:
        print(f"An error occurred: {e}")
        response_text = "I'm having trouble processing your request right now."
    return response_text

def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        audio = r.listen(source)
        try:
            print("Recognizing...")
            query = r.recognize_google(audio, language="en-in")
            print(f"User said: {query}")
            return query
        except sr.UnknownValueError:
            return "I didn't catch that. Could you please repeat?"
        except sr.RequestError as e:
            return "Sorry, I'm having trouble accessing the speech recognition service."

if __name__ == '__main__':
    print('Welcome to jarvis A.I')
    say("jarvis AI", rate=150)
    while True:
        print("Listening...")
        query = takeCommand()

        sites = [
            ["youtube", "https://www.youtube.com"],
            ["wikipedia", "https://www.wikipedia.com"],
            ["google", "https://www.google.com"],
            ["RGPV", "https://www.rgpv.ac.in/"],
            ["instagram", "https://www.instagram.com"],
            ["facebook", "https://www.facebook.com"],
            ["erp", "https://tgi.instituteoncloud.com/Account/Login?ReturnUrl=%2F"]
        ]
        for site in sites:
            if f"open {site[0]}".lower() in query.lower():
                say(f"Opening {site[0]} sir...", rate=180)
                webbrowser.open(site[1])

        links = [
            ["my favourite song", "https://youtu.be/_CWcBWSKItk?si=lY9x7CI4K_12fo0Q"]
        ]

        for link in links:
            if f"play {link[0]}".lower() in query.lower():
                say(f"Playing {link[0]} sir...", rate=180)
                webbrowser.open(link[1])

        if "open music" in query.lower():
            musicPath = "/Users/harry/Downloads/downfall-21371.mp3"
            os.system(f"open {musicPath}")

        elif "the time" in query.lower():
            current_time = datetime.datetime.now().strftime("%I:%M %p")
            say(f"Sir, the time is {current_time}", rate=180)

        elif "open facetime" in query.lower():
            os.system("open /System/Applications/FaceTime.app")

        elif "open pass" in query.lower():
            os.system("open /Applications/Passky.app")

        elif "using your intelligence" in query.lower():
            ai(prompt=query)
            say("Done sir. Check your folder for the file.", rate=160)

        elif "ok bye" in query.lower() or "stop" in query.lower() or "bye" in query.lower():
            say("No problem sir. Have a great day!", rate=160)
            exit()

        elif "reset chat" in query.lower():
            chatStr = ""

        else:
            print("Chatting....")
            chat(query)
